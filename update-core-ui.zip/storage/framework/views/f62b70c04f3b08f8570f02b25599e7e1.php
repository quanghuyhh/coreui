<div class="sidebar sidebar-dark sidebar-fixed" id="sidebar">
    <div class="sidebar-brand d-none d-md-flex">
        <svg class="sidebar-brand-full" width="118" height="46" alt="CoreUI Logo">
            <use xlink:href="<?php echo e(asset('/assets/admin/assets/brand/coreui.svg#full')); ?>"></use>
        </svg>
        <svg class="sidebar-brand-narrow" width="46" height="46" alt="CoreUI Logo">
            <use xlink:href="<?php echo e(asset('/assets/admin/assets/brand/coreui.svg#signet')); ?>"></use>
        </svg>
    </div>
    <ul class="sidebar-nav" data-coreui="navigation" data-simplebar="">
        <li class="nav-item">
            <a class="nav-link" href="/" wire:navigate>
                <svg class="nav-icon">
                    <use xlink:href="<?php echo e(asset('/assets/admin/vendors/@coreui/icons/svg/free.svg#cil-speedometer')); ?>"></use>
                </svg> <?php echo e($isManager ? 'Manager' : 'Teacher'); ?> Dashboard
            </a>
        </li>
        <!--[if BLOCK]><![endif]--><?php if($isManager): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('admin.roles.index')); ?>" wire:navigate>
                    <svg class="nav-icon">
                        <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-drop"></use>
                    </svg> Roles
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('admin.schools.index')); ?>" wire:navigate>
                    <svg class="nav-icon">
                        <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-drop"></use>
                    </svg> Schools
                </a>
            </li>
        <?php else: ?>
            <li class="nav-item">
                <a class="nav-link" href="" wire:navigate>
                    <svg class="nav-icon">
                        <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-drop"></use>
                    </svg> Teacher Menu
                </a>
            </li>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    </ul>
    <button class="sidebar-toggler" type="button" data-coreui-toggle="unfoldable"></button>
</div>
<?php /**PATH /var/www/html/resources/views/livewire/layout/sidebar.blade.php ENDPATH**/ ?>