<a class="dropdown-item" href="#logout" wire:click.prevent="logout">
    <svg class="icon me-2">
        <use xlink:href="<?php echo e(asset('/assets/admin/vendors/@coreui/icons/svg/free.svg#cil-account-logout')); ?>"></use>
    </svg> Logout
</a>
<?php /**PATH /var/www/html/resources/views/livewire/auth/logout.blade.php ENDPATH**/ ?>