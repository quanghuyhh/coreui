<?php

return [
    'manager' => 'admin.dashboard',
    'teacher' => 'teacher.dashboard',
    'headquarter' => 'admin.dashboard',
];
