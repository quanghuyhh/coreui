@extends('layout.guest')

@section('main')
    @livewire('auth.login')
@endsection
