<a class="dropdown-item" href="#logout" wire:click.prevent="logout">
    <svg class="icon me-2">
        <use xlink:href="{{ asset('/assets/admin/vendors/@coreui/icons/svg/free.svg#cil-account-logout') }}"></use>
    </svg> Logout
</a>
