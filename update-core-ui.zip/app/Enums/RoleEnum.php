<?php

namespace App\Enums;

enum RoleEnum : int
{
    case MANAGER = 1;

    case TEACHER = 2;

    case HEADQUARTER = 3;
}
